# JEJAK UNDAGI
**Menjelajahi Teknologi dan Peradaban Nusantara**

Game petualangan edukasi 2D top-down tentang Masa Perundagian untuk Sejarah kelas X SMA.

## Menjalankan
1. Ekstrak ZIP.
2. Buka `index.html` di browser modern. Tidak perlu instalasi, akun, server, atau koneksi internet.
3. Untuk hosting, unggah seluruh isi folder ke repository GitHub lalu aktifkan **Settings → Pages → Deploy from a branch → main / root**. Alternatif: unggah ke Cloudflare Pages.

## Kontrol
- PC: WASD / tombol panah untuk bergerak, E atau Spasi untuk interaksi, Esc untuk menu.
- Mobile: tombol arah dan INTERAKSI di bawah layar.
- Tombol Tas, Misi, dan Peta tersedia di toolbar.

## Fitur
- Lima wilayah eksplorasi, NPC, objek pengetahuan, dialog, collision sederhana, perpindahan wilayah.
- Sepuluh misi utama dan jurnal progres.
- Inventory artefak, XP, level, peta, dan penyimpanan LocalStorage.
- Ujian 15 soal pilihan ganda dengan pembahasan dan rekap nilai.
- Canvas pixel-style procedural, sehingga aset visual dibuat lokal dan tidak perlu mengunduh aset eksternal.
- Tidak mengirim data pemain ke server.

## Catatan teknis
Proyek ini menggunakan HTML5 Canvas dan JavaScript murni (engine 2D ringan), bukan Phaser 3. Pendekatan ini dipilih agar tidak ada dependensi CDN sehingga file yang telah diunduh dapat langsung dimainkan secara offline. Kode utama ada di `game.js`; tampilan di `style.css`.

## Pengembangan lanjutan
Versi ini merupakan vertical slice yang dapat dimainkan dan menjadi fondasi pengembangan. Untuk produksi sekolah/kompetisi, disarankan menambahkan sprite-sheet animasi orisinal, tilemap artistik per wilayah, collision map terperinci, audio lokal, lebih banyak percakapan bercabang, dan uji perangkat lintas browser. Materi diringkas dan menghindari klaim bahwa semua komunitas Nusantara mengalami perubahan secara seragam.
