(()=>{
"use strict";
const canvas=document.querySelector("#game"),ctx=canvas.getContext("2d");
ctx.imageSmoothingEnabled=false;
const W=960,H=600,T=48,worldW=2000,worldH=1400;
const $=s=>document.querySelector(s);
const state={x:480,y:330,dir:0,xp:0,level:1,zone:0,items:[],done:[],audio:true,muted:false,keys:{},near:null,day:0};
const zones=[
{name:"Desa Prasejarah",x:0,y:0,w:900,h:700,color:"#477348",ground:"#65904d"},
{name:"Bengkel Undagi",x:900,y:0,w:650,h:700,color:"#79533b",ground:"#9a7149"},
{name:"Area Pertanian",x:0,y:700,w:900,h:700,color:"#688d42",ground:"#82a64c"},
{name:"Pelabuhan Dagang",x:900,y:700,w:650,h:700,color:"#397b83",ground:"#c2a36b"},
{name:"Situs Megalitik",x:1550,y:0,w:450,h:1400,color:"#536d4a",ground:"#73834c"}];
const missions=[
["Mengenal Masa Perundagian","Temui tetua desa dan pelajari arti kata undagi.","Tetua","Masa Perundagian adalah masa ketika keahlian khusus berkembang, terutama dalam pengolahan logam. Kata undagi merujuk pada orang yang memiliki keterampilan atau keahlian tertentu."],
["Ciri kehidupan masyarakat","Amati rumah dan aktivitas warga desa.","Warga","Masyarakat hidup menetap dalam kelompok, mengenal pembagian kerja, menghasilkan pangan, dan mengembangkan kerajinan. Bentuk kehidupan berbeda menurut lingkungan dan wilayah."],
["Profesi undagi","Bicaralah dengan ahli logam di bengkel.","Undagi","Undagi adalah tenaga ahli/pengrajin yang menguasai keterampilan tertentu, termasuk pembuatan benda logam. Keahlian mereka membutuhkan pengalaman dan pengetahuan teknis."],
["Teknik bivalve","Pelajari cetakan dua bagian bersama undagi.","Cetakan","Teknik bivalve memakai cetakan yang terdiri atas dua bagian yang dapat disatukan. Logam cair dituangkan ke rongga cetakan; cetakan dapat digunakan kembali jika tidak rusak."],
["Teknik a cire perdue","Periksa model lilin di meja pengrajin.","Model lilin","A cire perdue atau teknik cetak lilin hilang menggunakan model lilin yang dilapisi bahan cetakan. Saat dipanaskan, lilin keluar dan rongga kemudian diisi logam cair. Cetakan umumnya sekali pakai."],
["Hasil kebudayaan logam","Temukan contoh benda logam di bengkel.","Artefak","Benda hasil kebudayaan logam antara lain nekara, moko, kapak corong, bejana perunggu, perhiasan, dan alat-alat tertentu. Sebaran dan fungsi benda berbeda antarwilayah."],
["Nekara dan moko","Tanyakan perbedaan nekara dan moko kepada pedagang.","Nekara","Nekara adalah genderang perunggu besar, sedangkan moko merupakan bentuk nekara berukuran lebih kecil yang dikenal terutama di wilayah Alor. Keduanya memiliki fungsi sosial-ritual pada konteks tertentu."],
["Kehidupan sosial dan kerja","Bantu petani dan pengrajin memahami pembagian kerja.","Petani","Spesialisasi pekerjaan berkembang seiring kebutuhan masyarakat. Petani, nelayan, pengrajin, dan pedagang saling bergantung; tingkat organisasi sosial berbeda menurut komunitas."],
["Perdagangan antardaerah","Bertukar informasi dengan pedagang di dermaga.","Pedagang","Benda logam, bahan baku, dan hasil bumi berpindah melalui jaringan pertukaran. Perdagangan membantu penyebaran teknologi dan gaya budaya, melalui jalur darat maupun laut."],
["Ujian akhir sejarah","Selesaikan kuis pengetahuan Masa Perundagian.","Penguji","Kamu telah menelusuri teknologi, ekonomi, kehidupan sosial, kepercayaan, dan peninggalan arkeologis. Ingat: perkembangan budaya Nusantara tidak seragam; tiap wilayah memiliki kronologi dan ciri khas."]];
const npcs=[
{x:340,y:300,name:"Tetua",role:"Tetua Desa",color:"#e7b75d",mission:0,dialog:"Salam, pengembara. Desa kita berkembang berkat pengetahuan dan keterampilan. Mari pahami masa ketika para ahli mulai dikenal sebagai undagi."},
{x:1130,y:300,name:"Undagi",role:"Ahli Logam",color:"#d77b4b",mission:2,dialog:"Aku seorang undagi. Perhatikan cetakan ini. Ada teknik bivalve dan a cire perdue; keduanya berbeda dalam cara membuat cetakan."},
{x:1280,y:420,name:"Pengrajin",role:"Pengrajin Perhiasan",color:"#e5cf8c",mission:5,dialog:"Perunggu dapat dibentuk menjadi benda upacara, alat, dan perhiasan. Nekara dan moko merupakan peninggalan penting, tetapi bentuk serta penggunaannya beragam."},
{x:430,y:980,name:"Petani",role:"Petani",color:"#a8c66a",mission:7,dialog:"Kami mengolah lahan dan mengatur air bersama. Hasil pangan mendukung kehidupan komunitas dan memungkinkan sebagian orang menekuni pekerjaan lain."},
{x:1130,y:1000,name:"Pedagang",role:"Pedagang",color:"#d7a6a0",mission:8,dialog:"Barang dan gagasan berpindah antarpulau. Jaringan pertukaran membantu masyarakat memperoleh bahan yang tidak tersedia di lingkungannya."},
{x:1740,y:480,name:"Penjaga Situs",role:"Penjaga Situs",color:"#9eb4a0",mission:1,dialog:"Situs ini menyimpan tradisi megalitik. Menhir, dolmen, sarkofagus, dan punden berundak berkaitan dengan praktik kepercayaan dan penghormatan kepada leluhur di berbagai komunitas."}
];
npcs.push({x:1450,y:610,name:"Peniup Nekara",role:"Penjaga Koleksi",color:"#d9b86b",mission:6,dialog:"Nekara adalah genderang perunggu berukuran besar. Moko merupakan bentuk yang lebih kecil dan dikenal terutama di Alor. Keduanya memiliki konteks sosial dan ritual yang beragam."});\nconst objects=[
{x:520,y:430,label:"Rumah panggung",info:"Rumah dan permukiman mencerminkan adaptasi masyarakat terhadap lingkungan. Bentuk hunian prasejarah di Nusantara beragam; rumah panggung tidak boleh dianggap mewakili semua komunitas.",mission:1},
{x:1000,y:250,label:"Cetakan bivalve",info:"Bivalve adalah cetakan dua sisi yang disatukan sebelum logam cair dituangkan. Cetakan dapat digunakan berulang kali.",mission:3},
{x:1400,y:250,label:"Model lilin",info:"Pada teknik a cire perdue, model lilin dilelehkan/keluar dari cetakan saat pemanasan, meninggalkan rongga untuk logam cair.",mission:4},
{x:1200,y:550,label:"Koleksi perunggu",info:"Kapak corong, nekara, moko, bejana, dan perhiasan merupakan beberapa hasil teknologi logam. Temuan arkeologis menunjukkan variasi regional.",mission:5},
{x:1150,y:1180,label:"Dermaga",info:"Pertukaran barang dan bahan baku menghubungkan komunitas. Bukti perdagangan dapat ditelusuri melalui persebaran artefak dan bahan.",mission:8},
{x:1770,y:800,label:"Menhir",info:"Menhir ialah batu tegak yang didirikan sebagai bagian dari tradisi megalitik; makna dan konteksnya bervariasi.",mission:1},
{x:1880,y:920,label:"Dolmen",info:"Dolmen berupa susunan batu menyerupai meja, dalam sejumlah konteks berkaitan dengan penguburan atau penghormatan kepada leluhur.",mission:1},
{x:1740,y:1080,label:"Sarkofagus",info:"Sarkofagus batu merupakan wadah kubur. Temuan dan bentuknya memiliki variasi regional.",mission:1},
{x:1900,y:1190,label:"Punden berundak",info:"Punden berundak adalah bangunan bertingkat dari susunan teras, terkait tradisi pemujaan atau penghormatan leluhur di sejumlah wilayah.",mission:1},\n{x:1840,y:1320,label:"Meja ujian akhir",info:"Kamu telah mengumpulkan catatan dari berbagai wilayah. Mulai ujian akhir untuk menguji pemahamanmu.",mission:9}
];
const quiz=[
["Apa arti undagi dalam konteks Masa Perundagian?",["Ahli dengan keterampilan khusus","Pemimpin perang","Petani ladang","Pelaut asing"],0,"Undagi berarti orang yang memiliki keahlian atau keterampilan khusus."],
["Teknik bivalve menggunakan…",["Model lilin","Cetakan dua bagian","Batu pipih","Tempa besi saja"],1,"Bivalve memakai cetakan dua bagian yang disatukan."],
["Teknik a cire perdue dikenal sebagai teknik…",["Cetak lilin hilang","Cetak batu terbuka","Tempa dingin","Pahat kayu"],0,"Model lilin dikeluarkan saat cetakan dipanaskan, lalu rongga diisi logam cair."],
["Nekara umumnya dibuat dari…",["Perunggu","Kaca","Kertas","Tanah liat saja"],0,"Nekara merupakan genderang perunggu."],
["Moko dikenal terutama dari wilayah…",["Alor","Sumatra Utara","Jawa Barat","Kalimantan Barat"],0,"Moko dikenal sebagai nekara berukuran lebih kecil yang banyak ditemukan di Alor."],
["Salah satu ciri Masa Perundagian adalah…",["Spesialisasi keahlian","Tidak ada pertukaran","Semua hidup berpindah","Tidak mengenal kerajinan"],0,"Keahlian khusus dan pembagian kerja berkembang dalam masyarakat."],
["Contoh hasil budaya logam adalah…",["Kapak corong","Kapak genggam paleolitik saja","Gerabah modern","Kertas lontar"],0,"Kapak corong merupakan salah satu artefak logam prasejarah."],
["Bivalve dapat digunakan kembali jika…",["Cetakan tetap utuh","Lilin masih utuh","Tidak pernah dibuka","Terbuat dari kain"],0,"Cetakan dua bagian dapat digunakan berulang selama tidak rusak."],
["A cire perdue biasanya menghasilkan cetakan yang…",["Sekali pakai","Selalu lentur","Dapat dilipat","Terbuat dari kaca"],0,"Cetakan lilin hilang umumnya dihancurkan untuk mengeluarkan benda cor."],
["Pertukaran antardaerah berperan dalam…",["Penyebaran bahan dan teknologi","Menghentikan semua kontak","Menghapus kerajinan","Membatasi pengetahuan"],0,"Jaringan pertukaran memungkinkan bahan, benda, dan gagasan bergerak."],
["Menhir adalah…",["Batu tegak","Genderang perunggu","Wadah air","Alat tenun"],0,"Menhir merupakan batu tegak dalam tradisi megalitik."],
["Dolmen sering berbentuk…",["Meja batu","Perahu kayu","Rumah bundar","Kapak besi"],0,"Dolmen berupa susunan batu menyerupai meja."],
["Sarkofagus merupakan…",["Wadah kubur batu","Alat pertanian logam","Perhiasan emas","Cetakan perunggu"],0,"Sarkofagus adalah wadah kubur dari batu."],
["Mengapa pembagian kerja berkembang?",["Keahlian dan kebutuhan makin beragam","Tidak ada hasil pangan","Semua pekerjaan sama","Karena teknologi hilang"],0,"Spesialisasi memungkinkan orang menekuni pekerjaan tertentu dan saling memenuhi kebutuhan."],
["Pernyataan paling tepat tentang Masa Perundagian Nusantara adalah…",["Perkembangannya beragam antarwilayah","Terjadi serentak dan sama di semua tempat","Hanya ada di satu pulau","Tidak meninggalkan artefak"],0,"Kronologi, bentuk artefak, dan praktik sosial berbeda menurut wilayah."],
];
function toast(s){const el=$("#toast");el.textContent=s;el.classList.add("show");setTimeout(()=>el.classList.remove("show"),2200)}
function save(){localStorage.setItem("jejakUndagiSave",JSON.stringify({x:state.x,y:state.y,xp:state.xp,level:state.level,zone:state.zone,items:state.items,done:state.done,audio:state.audio}));}
function load(){try{const d=JSON.parse(localStorage.getItem("jejakUndagiSave"));if(d)Object.assign(state,d)}catch{}}
load();\nif("serviceWorker" in navigator && location.protocol.startsWith("http")) navigator.serviceWorker.register("./sw.js").catch(()=>{});
function updateHud(){$("#xp").textContent=state.xp;$("#level").textContent=state.level;$("#zone").textContent=zones[state.zone].name}
function complete(i){if(state.done.includes(i))return;state.done.push(i);state.xp+=100;state.level=1+Math.floor(state.xp/300);state.items.push(["Lencana Penjelajah","Catatan Kehidupan","Lencana Pengamat","Sketsa Bivalve","Sketsa A cire perdue","Katalog Perunggu","Catatan Nekara & Moko","Catatan Pembagian Kerja","Peta Pertukaran","Sertifikat Undagi"][i]);toast("Misi selesai! +100 XP");save();updateHud()}
function startMission(i){if(i===9){showQuiz();return}complete(i)}
function showDialog(n){$("#dialogName").textContent=n.role;$("#dialogText").textContent=n.dialog;const a=$("#dialogActions");a.innerHTML="";let b=document.createElement("button");b.textContent="Pelajari & catat (+100 XP)";b.onclick=()=>{startMission(n.mission);hide("dialog")};a.append(b);let c=document.createElement("button");c.textContent="Tutup";c.onclick=()=>hide("dialog");a.append(c);show("dialog")}
function showObject(o){$("#dialogName").textContent=o.label;$("#dialogText").textContent=o.info;const a=$("#dialogActions");a.innerHTML="";let b=document.createElement("button");b.textContent="Catat temuan (+100 XP)";b.onclick=()=>{complete(o.mission);hide("dialog")};a.append(b);let c=document.createElement("button");c.textContent="Tutup";c.onclick=()=>hide("dialog");a.append(c);show("dialog")}
function showQuiz(){let q=$("#quiz");q.innerHTML="<h2>Ujian Akhir: Masa Perundagian</h2><p class='muted'>15 pertanyaan • Pilih jawaban terbaik. Pembahasan muncul setelah setiap jawaban.</p><div id='quizBody'></div>";show("quiz");let order=quiz.map((_,i)=>i);let idx=0,score=0;function render(){let body=$("#quizBody");if(idx>=order.length){body.innerHTML=`<h3>Evaluasi selesai</h3><p>Skor: <b>${score}/${quiz.length*10}</b></p><p>${score>=120?"Sangat baik! Pemahamanmu kuat.":score>=90?"Bagus. Pelajari kembali pembahasan yang belum tepat.":"Terus berlatih. Baca kembali jurnal dan materi misi."}</p><button id='finishQuiz'>Simpan hasil & tutup</button>`;$("#finishQuiz").onclick=()=>{complete(9);state.xp+=score;state.level=1+Math.floor(state.xp/300);save();updateHud();hide("quiz")};return}let [question,opts,ans,ex]=quiz[order[idx]];body.innerHTML=`<p class='muted'>Soal ${idx+1} dari ${quiz.length}</p><h3>${question}</h3><div id='opts'></div><div id='explain'></div>`;opts.forEach((v,i)=>{let b=document.createElement("button");b.className="choice";b.textContent=String.fromCharCode(65+i)+". "+v;b.onclick=()=>{if($("#explain").dataset.done)return;$("#explain").dataset.done="1";if(i===ans){score+=10;$("#explain").innerHTML="<p class='good'>Benar. +10 poin</p><p>"+ex+"</p>"}else $("#explain").innerHTML="<p class='bad'>Belum tepat.</p><p>"+ex+"</p>";let n=document.createElement("button");n.textContent=idx===quiz.length-1?"Lihat hasil":"Soal berikutnya";n.onclick=()=>{idx++;render()};$("#explain").append(n)};$("#opts").append(b)})}render()}
function show(id){$("#"+id).classList.remove("hidden")}function hide(id){$("#"+id).classList.add("hidden")}
function panel(kind){["inventory","mapPanel","questPanel","menuPanel"].forEach(hide);if(kind==="inventory"){let el=$("#inventory");el.innerHTML="<h2>Inventory & Artefak</h2>"+(state.items.length?state.items.map(x=>`<div class='item'>◆ ${x}</div>`).join(""):"<p class='muted'>Belum ada artefak. Selesaikan misi untuk mengumpulkan catatan.</p>");show("inventory")}if(kind==="quests"){let el=$("#questPanel");el.innerHTML="<h2>Jurnal Misi</h2>"+missions.map((m,i)=>`<div class='item'><b>${i+1}. ${m[0]}</b><p class='muted'>${m[1]}</p><span class='${state.done.includes(i)?"good":"muted"}'>${state.done.includes(i)?"✓ Selesai":"○ Belum selesai"}</span></div>`).join("")+`<p>Progres: ${state.done.length}/10</p>`;show("questPanel")}if(kind==="map"){let el=$("#mapPanel");el.innerHTML="<h2>Peta Wilayah</h2>"+zones.map((z,i)=>`<div class='item'><b>${z.name}</b> <span class='muted'>${i===state.zone?"(wilayah saat ini)":""}</span><button data-zone='${i}'>Pergi</button></div>`).join("");el.querySelectorAll("[data-zone]").forEach(b=>b.onclick=()=>{let i=+b.dataset.zone;const z=zones[i];state.x=z.x+z.w/2;state.y=z.y+z.h/2;state.zone=i;save();updateHud();hide("mapPanel")});show("mapPanel")}if(kind==="menu")show("menuPanel")}
function nearest(){let list=[...npcs.map(n=>({...n,type:"npc"})),...objects.map(o=>({...o,type:"obj"}))];return list.map(o=>({...o,d:Math.hypot(o.x-state.x,o.y-state.y)})).filter(o=>o.d<76).sort((a,b)=>a.d-b.d)[0]||null}
const cam={x:0,y:0};let last=0;
function draw(){ctx.clearRect(0,0,W,H);let z=zones[state.zone];cam.x=Math.max(0,Math.min(worldW-W,state.x-W/2));cam.y=Math.max(0,Math.min(worldH-H,state.y-H/2));ctx.save();ctx.translate(-cam.x,-cam.y);
for(let y=0;y<worldH;y+=T)for(let x=0;x<worldW;x+=T){let zi=zones.findIndex(a=>x>=a.x&&x<a.x+a.w&&y>=a.y&&y<a.y+a.h);let c=zones[Math.max(0,zi)].ground;ctx.fillStyle=c;ctx.fillRect(x,y,T,T);let v=((x*13+y*7)%11);if(v<3){ctx.fillStyle=zi===3?"#d8bd83":"#476d3e";ctx.fillRect(x+v*8,y+14,4,4)}}
 // paths
ctx.fillStyle="#b79b69";ctx.fillRect(390,280,80,700);ctx.fillRect(390,960,780,70);ctx.fillRect(950,270,360,70);ctx.fillRect(1250,700,70,400);
 // water
ctx.fillStyle="#397f91";ctx.fillRect(900,1260,650,140);for(let i=0;i<20;i++){ctx.fillStyle="#74b2b2";ctx.fillRect(920+i*30,1280+(i%3)*22,18,3)}
 // houses
[[210,190],[540,180],[260,500],[650,480]].forEach(([x,y])=>house(x,y));
 // workshop
house(1060,180,true);house(1350,470,true);
 // fields
for(let i=0;i<7;i++){ctx.fillStyle=i%2?"#a6b85a":"#b8c66a";ctx.fillRect(100+i*85,800,65,190);for(let j=0;j<6;j++){ctx.fillStyle="#617e3e";ctx.fillRect(108+i*85,812+j*28,48,3)}}
 // megaliths
stone(1740,480,"menhir");stone(1880,920,"dolmen");stone(1740,1080,"sarc");stone(1900,1190,"punden");
 // props
for(let o of objects){ctx.fillStyle="#f4d477";ctx.fillRect(o.x-5,o.y-5,10,10);ctx.fillStyle="#fff3bd";ctx.font="12px monospace";ctx.fillText(o.label,o.x-36,o.y-18)}
for(let n of npcs)person(n.x,n.y,n.color,n.name);
person(state.x,state.y,"#e7e8d2","Kamu",true);
ctx.restore();
 // atmospheric overlay + location
ctx.fillStyle="#07130f";ctx.globalAlpha=.12+Math.sin(Date.now()/5000)*.04;ctx.fillRect(0,0,W,H);ctx.globalAlpha=1;
ctx.fillStyle="#f7edce";ctx.font="bold 16px monospace";ctx.fillText(zones[state.zone].name,18,28);
let near=nearest();state.near=near;if(near){ctx.fillStyle="#fff1b8";ctx.font="bold 14px monospace";ctx.fillText("E / INTERAKSI  •  "+(near.label||near.name),18,H-20)}
}
function house(x,y,forge=false){ctx.fillStyle="#46372d";ctx.fillRect(x,y+30,120,65);ctx.fillStyle=forge?"#8d5035":"#a85e3d";ctx.fillRect(x-8,y+8,136,34);ctx.fillStyle="#d9a75e";ctx.fillRect(x+10,y+40,100,6);for(let i=0;i<4;i++)ctx.fillRect(x+12+i*28,y+62,5,32);ctx.fillStyle="#253d35";ctx.fillRect(x+50,y+52,22,42);if(forge){ctx.fillStyle="#f28c3b";ctx.fillRect(x+44,y+75,34,18);ctx.fillStyle="#ffd56b";ctx.fillRect(x+53,y+78,16,10)}}
function person(x,y,color,label,player=false){ctx.fillStyle="#17231c";ctx.fillRect(x-10,y+15,22,7);ctx.fillStyle=color;ctx.fillRect(x-8,y-18,17,28);ctx.fillStyle="#d9a77a";ctx.fillRect(x-7,y-30,15,13);ctx.fillStyle="#49362a";ctx.fillRect(x-8,y-33,17,5);if(player){ctx.fillStyle="#f3d06d";ctx.fillRect(x-12,y-40,24,4)}}
function stone(x,y,type){ctx.fillStyle="#727b68";if(type==="menhir")ctx.fillRect(x-13,y-55,26,60);else if(type==="dolmen"){ctx.fillRect(x-35,y-12,70,14);ctx.fillRect(x-27,y-45,13,35);ctx.fillRect(x+15,y-45,13,35)}else if(type==="sarc"){ctx.fillRect(x-35,y-18,70,28);ctx.fillRect(x-42,y-24,84,9)}else{for(let i=0;i<4;i++)ctx.fillRect(x-40+i*4,y-i*17,80-i*8,12)}}
function move(dt){let k=state.keys,dx=0,dy=0;if(k.arrowleft||k.a||k.left)dx--;if(k.arrowright||k.d||k.right)dx++;if(k.arrowup||k.w||k.up)dy--;if(k.arrowdown||k.s||k.down)dy++;if(dx&&dy){dx*=.707;dy*=.707}let speed=190;let nx=Math.max(24,Math.min(worldW-24,state.x+dx*speed*dt)),ny=Math.max(30,Math.min(worldH-24,state.y+dy*speed*dt));if(!blocked(nx,ny)){state.x=nx;state.y=ny}let zi=zones.findIndex(a=>state.x>=a.x&&state.x<a.x+a.w&&state.y>=a.y&&state.y<a.y+a.h);if(zi>=0&&zi!==state.zone){state.zone=zi;updateHud();save()}}
function blocked(x,y){return [[210,190,125,100],[540,180,125,100],[260,500,125,100],[650,480,125,100],[1060,180,125,100],[1350,470,125,100]].some(([a,b,w,h])=>x>a-20&&x<a+w+20&&y>b-15&&y<b+h+10)}
function interact(){let n=nearest();if(!n){toast("Tidak ada yang cukup dekat.");return}if(n.type==="npc")showDialog(n);else showObject(n)}
function loop(t){let dt=Math.min(.04,(t-last)/1000||0);last=t;if(!document.querySelector(".panel:not(.hidden)"))move(dt);draw();requestAnimationFrame(loop)}
window.addEventListener("keydown",e=>{let k=e.key.toLowerCase();if(["arrowup","arrowdown","arrowleft","arrowright"," "].includes(k))e.preventDefault();state.keys[k]=true;if(k==="e"||k===" ")interact();if(k==="escape")panel("menu")});window.addEventListener("keyup",e=>state.keys[e.key.toLowerCase()]=false);
document.querySelectorAll("[data-move]").forEach(b=>{let k=b.dataset.move;b.addEventListener("pointerdown",e=>{e.preventDefault();state.keys[k]=true});["pointerup","pointerleave","pointercancel"].forEach(ev=>b.addEventListener(ev,()=>state.keys[k]=false))});
$("#interact").onclick=interact;$("#menuBtn").onclick=()=>panel("menu");
document.querySelectorAll("[data-action]").forEach(b=>b.onclick=()=>{let a=b.dataset.action;if(a==="resume"){hide("menuPanel");return}if(a==="audio"){state.audio=!state.audio;$("#audioState").textContent=state.audio?"Aktif":"Nonaktif";return}if(a==="reset"){if(confirm("Hapus progres tersimpan dan mulai ulang?")){localStorage.removeItem("jejakUndagiSave");location.reload()}return}panel(a)});
document.querySelectorAll("[data-close]").forEach(b=>b.onclick=()=>hide(b.dataset.close));
updateHud();requestAnimationFrame(loop);
})();